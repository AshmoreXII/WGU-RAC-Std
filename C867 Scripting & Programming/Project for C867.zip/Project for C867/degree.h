
#ifndef DEGREEH
#define DEGREEH

enum class DegreeProgram {SECURITY, NETWORK, SOFTWARE};       //works??
    

#endif